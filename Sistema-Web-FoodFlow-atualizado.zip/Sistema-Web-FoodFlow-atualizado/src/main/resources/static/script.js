const API = "";
let token = localStorage.getItem("foodflow_token") || "";

function headers(){
  const h = {"Content-Type":"application/json"};
  if(token) h["Authorization"] = `Bearer ${token}`;
  return h;
}

async function request(url, options={}){
  const resp = await fetch(API + url, {...options, headers: {...headers(), ...(options.headers || {})}});
  const text = await resp.text();
  let data = text;
  try { data = text ? JSON.parse(text) : null; } catch(e) {}
  if(!resp.ok) throw data;
  return data;
}

function show(id, data){ document.getElementById(id).textContent = JSON.stringify(data, null, 2); }

async function login(){
  try{
    const data = await request('/auth/login', {method:'POST', body: JSON.stringify({username: username.value, password: password.value})});
    token = data.token;
    localStorage.setItem('foodflow_token', token);
    statusLogin.textContent = 'Login realizado com sucesso!';
  }catch(e){ statusLogin.textContent = 'Erro no login: ' + JSON.stringify(e); }
}

async function listar(url, saida){
  try{ show(saida, await request(url)); }catch(e){ show(saida, e); }
}

async function criarCategoria(){
  try{ show('saidaCategorias', await request('/categorias', {method:'POST', body:JSON.stringify({nome:categoriaNome.value})})); }
  catch(e){ show('saidaCategorias', e); }
}

async function criarProduto(){
  try{ show('saidaProdutos', await request('/produtos', {method:'POST', body:JSON.stringify({nome:produtoNome.value, descricao:produtoDescricao.value, preco:Number(produtoPreco.value), disponivel:true, restauranteId:Number(produtoRestauranteId.value), categoriasIds:[Number(produtoCategoriaId.value)]})})); }
  catch(e){ show('saidaProdutos', e); }
}

async function criarPedido(){
  try{ show('saidaPedidos', await request('/pedidos', {method:'POST', body:JSON.stringify({clienteId:Number(pedidoClienteId.value), restauranteId:Number(pedidoRestauranteId.value), itens:[{produtoId:Number(pedidoProdutoId.value), quantidade:Number(pedidoQuantidade.value)}]})})); }
  catch(e){ show('saidaPedidos', e); }
}

async function criarAvaliacao(){
  try{ show('saidaAvaliacoes', await request('/avaliacoes', {method:'POST', body:JSON.stringify({clienteId:Number(avaliacaoClienteId.value), restauranteId:Number(avaliacaoRestauranteId.value), nota:Number(avaliacaoNota.value), comentario:avaliacaoComentario.value})})); }
  catch(e){ show('saidaAvaliacoes', e); }
}
