package com.allyssonmast.hamburgueria.service;

import com.allyssonmast.hamburgueria.dto.UsuarioResponseDTO;

import java.util.List;

public interface UsuarioService {
    List<UsuarioResponseDTO> listar();
    UsuarioResponseDTO buscarPorId(Long id);
    void deletar(Long id);
}
