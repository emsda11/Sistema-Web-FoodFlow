package com.allyssonmast.hamburgueria.service;

import com.allyssonmast.hamburgueria.dto.ProdutoRequestDTO;
import com.allyssonmast.hamburgueria.dto.ProdutoResponseDTO;

import java.util.List;

public interface ProdutoService {
    ProdutoResponseDTO criar(ProdutoRequestDTO dto);
    List<ProdutoResponseDTO> listar();
    List<ProdutoResponseDTO> listarDisponiveis();
    List<ProdutoResponseDTO> listarPorRestaurante(Long restauranteId);
    ProdutoResponseDTO buscarPorId(Long id);
    ProdutoResponseDTO atualizar(Long id, ProdutoRequestDTO dto);
    void deletar(Long id);
}
