package com.allyssonmast.hamburgueria.service.impl;

import com.allyssonmast.hamburgueria.dto.AvaliacaoRequestDTO;
import com.allyssonmast.hamburgueria.dto.AvaliacaoResponseDTO;
import com.allyssonmast.hamburgueria.exception.NotFoundException;
import com.allyssonmast.hamburgueria.model.Avaliacao;
import com.allyssonmast.hamburgueria.model.Cliente;
import com.allyssonmast.hamburgueria.model.Restaurante;
import com.allyssonmast.hamburgueria.repository.primary.AvaliacaoRepository;
import com.allyssonmast.hamburgueria.repository.primary.ClienteRepository;
import com.allyssonmast.hamburgueria.repository.primary.RestauranteRepository;
import com.allyssonmast.hamburgueria.service.AuditService;
import com.allyssonmast.hamburgueria.service.AvaliacaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvaliacaoServiceImpl implements AvaliacaoService {
    @Autowired private AvaliacaoRepository avaliacaoRepository;
    @Autowired private ClienteRepository clienteRepository;
    @Autowired private RestauranteRepository restauranteRepository;
    @Autowired private AuditService auditService;

    @Override
    public AvaliacaoResponseDTO criar(AvaliacaoRequestDTO dto) {
        Cliente cliente = clienteRepository.findById(dto.getClienteId()).orElseThrow(() -> new NotFoundException("Cliente não encontrado"));
        Restaurante restaurante = restauranteRepository.findById(dto.getRestauranteId()).orElseThrow(() -> new NotFoundException("Restaurante não encontrado"));
        Avaliacao avaliacao = new Avaliacao();
        avaliacao.setCliente(cliente); avaliacao.setRestaurante(restaurante); avaliacao.setNota(dto.getNota()); avaliacao.setComentario(dto.getComentario());
        Avaliacao salva = avaliacaoRepository.save(avaliacao);
        auditService.registrar("Avaliacao", salva.getId(), "CREATE");
        return toDTO(salva);
    }
    @Override public List<AvaliacaoResponseDTO> listar(){ return avaliacaoRepository.findAll().stream().map(this::toDTO).toList(); }
    @Override public AvaliacaoResponseDTO buscarPorId(Long id){ return toDTO(buscarEntidade(id)); }
    @Override public List<AvaliacaoResponseDTO> listarPorRestaurante(Long restauranteId){ return avaliacaoRepository.findByRestauranteId(restauranteId).stream().map(this::toDTO).toList(); }
    @Override public List<AvaliacaoResponseDTO> listarPorCliente(Long clienteId){ return avaliacaoRepository.findByClienteId(clienteId).stream().map(this::toDTO).toList(); }
    @Override public void deletar(Long id){ Avaliacao avaliacao=buscarEntidade(id); avaliacaoRepository.delete(avaliacao); auditService.registrar("Avaliacao", id, "DELETE"); }
    private Avaliacao buscarEntidade(Long id){ return avaliacaoRepository.findById(id).orElseThrow(() -> new NotFoundException("Avaliação não encontrada")); }
    private AvaliacaoResponseDTO toDTO(Avaliacao a){ AvaliacaoResponseDTO dto=new AvaliacaoResponseDTO(); dto.setId(a.getId()); dto.setClienteId(a.getCliente().getId()); dto.setClienteNome(a.getCliente().getNome()); dto.setRestauranteId(a.getRestaurante().getId()); dto.setRestauranteNome(a.getRestaurante().getNome()); dto.setNota(a.getNota()); dto.setComentario(a.getComentario()); dto.setCriadoEm(a.getCriadoEm()); return dto; }
}
