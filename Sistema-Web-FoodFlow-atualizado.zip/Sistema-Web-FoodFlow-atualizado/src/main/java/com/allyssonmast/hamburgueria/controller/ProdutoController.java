package com.allyssonmast.hamburgueria.controller;

import com.allyssonmast.hamburgueria.dto.ProdutoRequestDTO;
import com.allyssonmast.hamburgueria.dto.ProdutoResponseDTO;
import com.allyssonmast.hamburgueria.service.ProdutoService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/produtos")
@Tag(name = "Produtos")
@SecurityRequirement(name = "bearerAuth")
public class ProdutoController {
    @Autowired private ProdutoService service;

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE')")
    @PostMapping
    public ResponseEntity<ProdutoResponseDTO> criar(@Valid @RequestBody ProdutoRequestDTO dto){ return ResponseEntity.status(HttpStatus.CREATED).body(service.criar(dto)); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE', 'CLIENTE')")
    @GetMapping
    public ResponseEntity<List<ProdutoResponseDTO>> listar(){ return ResponseEntity.ok(service.listar()); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE', 'CLIENTE')")
    @GetMapping("/disponiveis")
    public ResponseEntity<List<ProdutoResponseDTO>> listarDisponiveis(){ return ResponseEntity.ok(service.listarDisponiveis()); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE', 'CLIENTE')")
    @GetMapping("/restaurante/{restauranteId}")
    public ResponseEntity<List<ProdutoResponseDTO>> listarPorRestaurante(@PathVariable Long restauranteId){ return ResponseEntity.ok(service.listarPorRestaurante(restauranteId)); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE', 'CLIENTE')")
    @GetMapping("/{id}")
    public ResponseEntity<ProdutoResponseDTO> buscar(@PathVariable Long id){ return ResponseEntity.ok(service.buscarPorId(id)); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE')")
    @PutMapping("/{id}")
    public ResponseEntity<ProdutoResponseDTO> atualizar(@PathVariable Long id, @Valid @RequestBody ProdutoRequestDTO dto){ return ResponseEntity.ok(service.atualizar(id, dto)); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id){ service.deletar(id); return ResponseEntity.noContent().build(); }
}
