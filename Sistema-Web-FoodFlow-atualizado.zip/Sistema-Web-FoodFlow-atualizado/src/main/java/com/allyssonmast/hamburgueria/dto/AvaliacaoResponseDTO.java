package com.allyssonmast.hamburgueria.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class AvaliacaoResponseDTO {
    private Long id;
    private Long clienteId;
    private String clienteNome;
    private Long restauranteId;
    private String restauranteNome;
    private Integer nota;
    private String comentario;
    private LocalDateTime criadoEm;
}
