package com.allyssonmast.hamburgueria.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RelatorioResponseDTO {
    private long totalClientes;
    private long totalRestaurantes;
    private long totalProdutos;
    private long totalPedidos;
    private long totalAvaliacoes;
    private Double faturamentoTotal;
}
