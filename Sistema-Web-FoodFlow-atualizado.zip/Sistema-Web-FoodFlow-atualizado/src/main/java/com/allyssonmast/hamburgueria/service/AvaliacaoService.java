package com.allyssonmast.hamburgueria.service;

import com.allyssonmast.hamburgueria.dto.AvaliacaoRequestDTO;
import com.allyssonmast.hamburgueria.dto.AvaliacaoResponseDTO;

import java.util.List;

public interface AvaliacaoService {
    AvaliacaoResponseDTO criar(AvaliacaoRequestDTO dto);
    List<AvaliacaoResponseDTO> listar();
    AvaliacaoResponseDTO buscarPorId(Long id);
    List<AvaliacaoResponseDTO> listarPorRestaurante(Long restauranteId);
    List<AvaliacaoResponseDTO> listarPorCliente(Long clienteId);
    void deletar(Long id);
}
