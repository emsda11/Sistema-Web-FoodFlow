package com.allyssonmast.hamburgueria.dto;

import com.allyssonmast.hamburgueria.enums.Role;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UsuarioResponseDTO {
    private Long id;
    private String username;
    private Role role;
}
