package com.allyssonmast.hamburgueria.config;

// import com.allyssonmast.hamburgueria.enums.Role;
// import com.allyssonmast.hamburgueria.model.Categoria;
// import com.allyssonmast.hamburgueria.model.Cliente;
// import com.allyssonmast.hamburgueria.model.Produto;
// import com.allyssonmast.hamburgueria.model.Restaurante;
// import com.allyssonmast.hamburgueria.model.Usuario;
// import com.allyssonmast.hamburgueria.repository.primary.CategoriaRepository;
// import com.allyssonmast.hamburgueria.repository.primary.ClienteRepository;
// import com.allyssonmast.hamburgueria.repository.primary.ProdutoRepository;
// import com.allyssonmast.hamburgueria.repository.primary.RestauranteRepository;
// import com.allyssonmast.hamburgueria.repository.primary.UsuarioRepository;
// import org.springframework.boot.CommandLineRunner;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;
// import org.springframework.security.crypto.password.PasswordEncoder;
// import org.springframework.transaction.annotation.Transactional;
//
// import java.util.Set;

// @Configuration
public class DataInitializer {

}