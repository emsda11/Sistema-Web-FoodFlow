package com.allyssonmast.hamburgueria.controller;

import com.allyssonmast.hamburgueria.dto.CategoriaRequestDTO;
import com.allyssonmast.hamburgueria.dto.CategoriaResponseDTO;
import com.allyssonmast.hamburgueria.service.CategoriaService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/categorias")
@Tag(name = "Categorias")
@SecurityRequirement(name = "bearerAuth")
public class CategoriaController {
    @Autowired private CategoriaService service;

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE')")
    @PostMapping
    public ResponseEntity<CategoriaResponseDTO> criar(@Valid @RequestBody CategoriaRequestDTO dto){ return ResponseEntity.status(HttpStatus.CREATED).body(service.criar(dto)); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE', 'CLIENTE')")
    @GetMapping
    public ResponseEntity<List<CategoriaResponseDTO>> listar(){ return ResponseEntity.ok(service.listar()); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE', 'CLIENTE')")
    @GetMapping("/{id}")
    public ResponseEntity<CategoriaResponseDTO> buscar(@PathVariable Long id){ return ResponseEntity.ok(service.buscarPorId(id)); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE')")
    @PutMapping("/{id}")
    public ResponseEntity<CategoriaResponseDTO> atualizar(@PathVariable Long id, @Valid @RequestBody CategoriaRequestDTO dto){ return ResponseEntity.ok(service.atualizar(id, dto)); }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id){ service.deletar(id); return ResponseEntity.noContent().build(); }
}
