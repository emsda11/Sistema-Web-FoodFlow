package com.allyssonmast.hamburgueria.service.impl;

import com.allyssonmast.hamburgueria.dto.UsuarioResponseDTO;
import com.allyssonmast.hamburgueria.exception.NotFoundException;
import com.allyssonmast.hamburgueria.model.Usuario;
import com.allyssonmast.hamburgueria.repository.primary.UsuarioRepository;
import com.allyssonmast.hamburgueria.service.AuditService;
import com.allyssonmast.hamburgueria.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioServiceImpl implements UsuarioService {
    @Autowired private UsuarioRepository usuarioRepository;
    @Autowired private AuditService auditService;
    @Override public List<UsuarioResponseDTO> listar(){ return usuarioRepository.findAll().stream().map(this::toDTO).toList(); }
    @Override public UsuarioResponseDTO buscarPorId(Long id){ return toDTO(buscarEntidade(id)); }
    @Override public void deletar(Long id){ Usuario usuario=buscarEntidade(id); usuarioRepository.delete(usuario); auditService.registrar("Usuario", id, "DELETE"); }
    private Usuario buscarEntidade(Long id){ return usuarioRepository.findById(id).orElseThrow(() -> new NotFoundException("Usuário não encontrado")); }
    private UsuarioResponseDTO toDTO(Usuario u){ UsuarioResponseDTO dto=new UsuarioResponseDTO(); dto.setId(u.getId()); dto.setUsername(u.getUsername()); dto.setRole(u.getRole()); return dto; }
}
