package com.allyssonmast.hamburgueria.controller;

import com.allyssonmast.hamburgueria.dto.RelatorioResponseDTO;
import com.allyssonmast.hamburgueria.service.RelatorioService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/relatorios")
@Tag(name = "Relatórios")
@SecurityRequirement(name = "bearerAuth")
public class RelatorioController {
    @Autowired private RelatorioService service;
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/resumo")
    public ResponseEntity<RelatorioResponseDTO> resumo(){ return ResponseEntity.ok(service.resumo()); }
}
