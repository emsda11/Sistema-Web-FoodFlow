package com.allyssonmast.hamburgueria.service.impl;

import com.allyssonmast.hamburgueria.dto.CategoriaRequestDTO;
import com.allyssonmast.hamburgueria.dto.CategoriaResponseDTO;
import com.allyssonmast.hamburgueria.exception.BusinessException;
import com.allyssonmast.hamburgueria.exception.NotFoundException;
import com.allyssonmast.hamburgueria.model.Categoria;
import com.allyssonmast.hamburgueria.repository.primary.CategoriaRepository;
import com.allyssonmast.hamburgueria.service.AuditService;
import com.allyssonmast.hamburgueria.service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaServiceImpl implements CategoriaService {
    @Autowired private CategoriaRepository repository;
    @Autowired private AuditService auditService;

    @Override
    public CategoriaResponseDTO criar(CategoriaRequestDTO dto) {
        repository.findByNomeIgnoreCase(dto.getNome()).ifPresent(c -> { throw new BusinessException("Categoria já cadastrada"); });
        Categoria categoria = new Categoria();
        categoria.setNome(dto.getNome());
        Categoria salva = repository.save(categoria);
        auditService.registrar("Categoria", salva.getId(), "CREATE");
        return toDTO(salva);
    }

    @Override public List<CategoriaResponseDTO> listar(){ return repository.findAll().stream().map(this::toDTO).toList(); }
    @Override public CategoriaResponseDTO buscarPorId(Long id){ return toDTO(buscarEntidade(id)); }

    @Override
    public CategoriaResponseDTO atualizar(Long id, CategoriaRequestDTO dto) {
        Categoria categoria = buscarEntidade(id);
        categoria.setNome(dto.getNome());
        Categoria atualizada = repository.save(categoria);
        auditService.registrar("Categoria", atualizada.getId(), "UPDATE");
        return toDTO(atualizada);
    }

    @Override
    public void deletar(Long id) {
        Categoria categoria = buscarEntidade(id);
        repository.delete(categoria);
        auditService.registrar("Categoria", id, "DELETE");
    }

    private Categoria buscarEntidade(Long id){ return repository.findById(id).orElseThrow(() -> new NotFoundException("Categoria não encontrada")); }
    private CategoriaResponseDTO toDTO(Categoria c){ CategoriaResponseDTO dto=new CategoriaResponseDTO(); dto.setId(c.getId()); dto.setNome(c.getNome()); return dto; }
}
