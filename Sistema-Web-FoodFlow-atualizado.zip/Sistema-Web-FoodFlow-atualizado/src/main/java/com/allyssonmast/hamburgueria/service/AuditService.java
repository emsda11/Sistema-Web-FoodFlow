package com.allyssonmast.hamburgueria.service;

import com.allyssonmast.hamburgueria.dto.AuditLogResponseDTO;
import java.util.List;

public interface AuditService {
    void registrar(String recurso, Long recursoId, String acao);
    List<AuditLogResponseDTO> listar();
}
