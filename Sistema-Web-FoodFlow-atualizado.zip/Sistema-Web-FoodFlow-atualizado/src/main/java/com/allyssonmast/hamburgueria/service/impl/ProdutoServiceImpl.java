package com.allyssonmast.hamburgueria.service.impl;

import com.allyssonmast.hamburgueria.dto.CategoriaResponseDTO;
import com.allyssonmast.hamburgueria.dto.ProdutoRequestDTO;
import com.allyssonmast.hamburgueria.dto.ProdutoResponseDTO;
import com.allyssonmast.hamburgueria.exception.NotFoundException;
import com.allyssonmast.hamburgueria.model.Categoria;
import com.allyssonmast.hamburgueria.model.Produto;
import com.allyssonmast.hamburgueria.model.Restaurante;
import com.allyssonmast.hamburgueria.repository.primary.CategoriaRepository;
import com.allyssonmast.hamburgueria.repository.primary.ProdutoRepository;
import com.allyssonmast.hamburgueria.repository.primary.RestauranteRepository;
import com.allyssonmast.hamburgueria.service.AuditService;
import com.allyssonmast.hamburgueria.service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ProdutoServiceImpl implements ProdutoService {
    @Autowired private ProdutoRepository produtoRepository;
    @Autowired private RestauranteRepository restauranteRepository;
    @Autowired private CategoriaRepository categoriaRepository;
    @Autowired private AuditService auditService;

    @Override
    public ProdutoResponseDTO criar(ProdutoRequestDTO dto) {
        Produto produto = new Produto();
        preencher(produto, dto);
        Produto salvo = produtoRepository.save(produto);
        auditService.registrar("Produto", salvo.getId(), "CREATE");
        return toDTO(salvo);
    }

    @Override public List<ProdutoResponseDTO> listar(){ return produtoRepository.findAll().stream().map(this::toDTO).toList(); }
    @Override public List<ProdutoResponseDTO> listarDisponiveis(){ return produtoRepository.findByDisponivelTrue().stream().map(this::toDTO).toList(); }
    @Override public List<ProdutoResponseDTO> listarPorRestaurante(Long restauranteId){ return produtoRepository.findByRestauranteId(restauranteId).stream().map(this::toDTO).toList(); }
    @Override public ProdutoResponseDTO buscarPorId(Long id){ return toDTO(buscarEntidade(id)); }

    @Override
    public ProdutoResponseDTO atualizar(Long id, ProdutoRequestDTO dto) {
        Produto produto = buscarEntidade(id);
        preencher(produto, dto);
        Produto atualizado = produtoRepository.save(produto);
        auditService.registrar("Produto", atualizado.getId(), "UPDATE");
        return toDTO(atualizado);
    }

    @Override
    public void deletar(Long id) {
        Produto produto = buscarEntidade(id);
        produtoRepository.delete(produto);
        auditService.registrar("Produto", id, "DELETE");
    }

    private void preencher(Produto produto, ProdutoRequestDTO dto) {
        Restaurante restaurante = restauranteRepository.findById(dto.getRestauranteId()).orElseThrow(() -> new NotFoundException("Restaurante não encontrado"));
        produto.setNome(dto.getNome());
        produto.setDescricao(dto.getDescricao());
        produto.setPreco(dto.getPreco());
        produto.setDisponivel(dto.getDisponivel() == null ? true : dto.getDisponivel());
        produto.setRestaurante(restaurante);
        Set<Categoria> categorias = new HashSet<>();
        if (dto.getCategoriasIds() != null) {
            for (Long categoriaId : dto.getCategoriasIds()) {
                categorias.add(categoriaRepository.findById(categoriaId).orElseThrow(() -> new NotFoundException("Categoria não encontrada: " + categoriaId)));
            }
        }
        produto.setCategorias(categorias);
    }

    private Produto buscarEntidade(Long id){ return produtoRepository.findById(id).orElseThrow(() -> new NotFoundException("Produto não encontrado")); }
    private ProdutoResponseDTO toDTO(Produto p){
        ProdutoResponseDTO dto = new ProdutoResponseDTO();
        dto.setId(p.getId()); dto.setNome(p.getNome()); dto.setDescricao(p.getDescricao()); dto.setPreco(p.getPreco()); dto.setDisponivel(p.getDisponivel());
        dto.setRestauranteId(p.getRestaurante().getId()); dto.setRestauranteNome(p.getRestaurante().getNome());
        dto.setCategorias(p.getCategorias().stream().map(c -> { CategoriaResponseDTO cr = new CategoriaResponseDTO(); cr.setId(c.getId()); cr.setNome(c.getNome()); return cr; }).collect(Collectors.toSet()));
        return dto;
    }
}
