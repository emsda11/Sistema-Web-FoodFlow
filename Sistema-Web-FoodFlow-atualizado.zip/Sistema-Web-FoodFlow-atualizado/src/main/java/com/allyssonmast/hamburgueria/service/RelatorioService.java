package com.allyssonmast.hamburgueria.service;

import com.allyssonmast.hamburgueria.dto.RelatorioResponseDTO;

public interface RelatorioService {
    RelatorioResponseDTO resumo();
}
