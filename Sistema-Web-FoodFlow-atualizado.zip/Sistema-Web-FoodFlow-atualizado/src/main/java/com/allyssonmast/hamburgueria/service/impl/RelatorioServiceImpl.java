package com.allyssonmast.hamburgueria.service.impl;

import com.allyssonmast.hamburgueria.dto.RelatorioResponseDTO;
import com.allyssonmast.hamburgueria.enums.StatusPagamento;
import com.allyssonmast.hamburgueria.repository.primary.*;
import com.allyssonmast.hamburgueria.service.RelatorioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RelatorioServiceImpl implements RelatorioService {
    @Autowired private ClienteRepository clienteRepository;
    @Autowired private RestauranteRepository restauranteRepository;
    @Autowired private ProdutoRepository produtoRepository;
    @Autowired private PedidoRepository pedidoRepository;
    @Autowired private AvaliacaoRepository avaliacaoRepository;
    @Autowired private PagamentoRepository pagamentoRepository;
    @Override
    public RelatorioResponseDTO resumo() {
        RelatorioResponseDTO dto = new RelatorioResponseDTO();
        dto.setTotalClientes(clienteRepository.count());
        dto.setTotalRestaurantes(restauranteRepository.count());
        dto.setTotalProdutos(produtoRepository.count());
        dto.setTotalPedidos(pedidoRepository.count());
        dto.setTotalAvaliacoes(avaliacaoRepository.count());
        double faturamento = pagamentoRepository.findAll().stream().filter(p -> p.getStatus() == StatusPagamento.PROCESSADO).mapToDouble(p -> p.getValor() == null ? 0.0 : p.getValor()).sum();
        dto.setFaturamentoTotal(faturamento);
        return dto;
    }
}
