package com.allyssonmast.hamburgueria.service.impl;

import com.allyssonmast.hamburgueria.dto.ClienteRequestDTO;
import com.allyssonmast.hamburgueria.dto.ClienteResponseDTO;
import com.allyssonmast.hamburgueria.exception.NotFoundException;
import com.allyssonmast.hamburgueria.model.Cliente;
import com.allyssonmast.hamburgueria.repository.primary.ClienteRepository;
import com.allyssonmast.hamburgueria.service.ClienteService;
import com.allyssonmast.hamburgueria.service.AuditService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteServiceImpl implements ClienteService {

    @Autowired
    private ClienteRepository repository;

    @Autowired
    private AuditService auditService;

    @Override
    public List<ClienteResponseDTO> listar() {

        return repository.findAll()
                .stream()
                .map(this::toResponseDTO)
                .toList();
    }

    @Override
    public ClienteResponseDTO buscarPorUsername(String username) {

        Cliente cliente = getClienteByUsername(username);

        return toResponseDTO(cliente);
    }

    @Override
    public ClienteResponseDTO buscarPorId(Long id) {

        Cliente cliente = buscarEntidadePorId(id);

        return toResponseDTO(cliente);
    }

    @Override
    public ClienteResponseDTO atualizar(
            Long id,
            ClienteRequestDTO dto
    ) {

        Cliente existente = buscarEntidadePorId(id);

        existente.setNome(dto.getNome());
        existente.setEmail(dto.getEmail());

        Cliente atualizado = repository.save(existente);
        auditService.registrar("Cliente", atualizado.getId(), "UPDATE");

        return toResponseDTO(atualizado);
    }

    @Override
    public ClienteResponseDTO atualizarMeuPerfil(String username, ClienteRequestDTO dto) {

        Cliente cliente = getClienteByUsername(username);

        cliente.setNome(dto.getNome());

        cliente.setEmail(dto.getEmail());

        Cliente atualizado = repository.save(cliente);
        auditService.registrar("Cliente", atualizado.getId(), "UPDATE_PROFILE");

        return toResponseDTO(atualizado);
    }

    public Cliente getClienteByUsername(String username) {

        return repository
                .findByUsuarioUsername(username)
                .orElseThrow(() ->
                        new NotFoundException("Cliente não encontrado"));
    }

    @Override
    public void deletar(Long id) {

        Cliente cliente = buscarEntidadePorId(id);

        repository.delete(cliente);
        auditService.registrar("Cliente", id, "DELETE");
    }

    @Override
    public void deletarMeuPerfil(String username) {

        Cliente cliente = getClienteByUsername(username);

        repository.delete(cliente);
        auditService.registrar("Cliente", cliente.getId(), "DELETE_PROFILE");
    }

    private Cliente buscarEntidadePorId(Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new NotFoundException("Cliente não encontrado")
                );
    }

    private ClienteResponseDTO toResponseDTO(Cliente cliente) {

        ClienteResponseDTO dto = new ClienteResponseDTO();

        dto.setId(cliente.getId());
        dto.setNome(cliente.getNome());
        dto.setEmail(cliente.getEmail());

        return dto;
    }
}