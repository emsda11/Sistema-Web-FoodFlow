package com.allyssonmast.hamburgueria.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class AuditLogResponseDTO {

    private Long id;
    private String recurso;
    private String acao;
    private Long recursoId;
    private LocalDateTime dataHora;
}
