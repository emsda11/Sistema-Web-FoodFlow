package com.allyssonmast.hamburgueria.controller;

import com.allyssonmast.hamburgueria.dto.AvaliacaoRequestDTO;
import com.allyssonmast.hamburgueria.dto.AvaliacaoResponseDTO;
import com.allyssonmast.hamburgueria.service.AvaliacaoService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/avaliacoes")
@Tag(name = "Avaliações")
@SecurityRequirement(name = "bearerAuth")
public class AvaliacaoController {
    @Autowired private AvaliacaoService service;

    @PreAuthorize("hasAnyRole('ADMIN', 'CLIENTE')")
    @PostMapping
    public ResponseEntity<AvaliacaoResponseDTO> criar(@Valid @RequestBody AvaliacaoRequestDTO dto){ return ResponseEntity.status(HttpStatus.CREATED).body(service.criar(dto)); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE', 'CLIENTE')")
    @GetMapping
    public ResponseEntity<List<AvaliacaoResponseDTO>> listar(){ return ResponseEntity.ok(service.listar()); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE', 'CLIENTE')")
    @GetMapping("/{id}")
    public ResponseEntity<AvaliacaoResponseDTO> buscar(@PathVariable Long id){ return ResponseEntity.ok(service.buscarPorId(id)); }

    @PreAuthorize("hasAnyRole('ADMIN', 'RESTAURANTE', 'CLIENTE')")
    @GetMapping("/restaurante/{restauranteId}")
    public ResponseEntity<List<AvaliacaoResponseDTO>> listarPorRestaurante(@PathVariable Long restauranteId){ return ResponseEntity.ok(service.listarPorRestaurante(restauranteId)); }

    @PreAuthorize("hasAnyRole('ADMIN', 'CLIENTE')")
    @GetMapping("/cliente/{clienteId}")
    public ResponseEntity<List<AvaliacaoResponseDTO>> listarPorCliente(@PathVariable Long clienteId){ return ResponseEntity.ok(service.listarPorCliente(clienteId)); }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id){ service.deletar(id); return ResponseEntity.noContent().build(); }
}
