
# Guia rápido de teste - FoodFlow integrado

## Executar

```bash
.\mvnw.cmd spring-boot:run
```

## Usuários iniciais

- ADMIN: `admin` / `123456`
- RESTAURANTE: `manager` / `123456`
- CLIENTE: `attendant` / `123456`

## Login

POST `/auth/login`

```json
{
  "username": "admin",
  "password": "123456"
}
```

Use o token retornado em `Authorization > Bearer Token`.

## Endpoints principais adicionados

### Categorias
- POST `/categorias`
- GET `/categorias`
- PUT `/categorias/{id}`
- DELETE `/categorias/{id}`

### Produtos
- POST `/produtos`
- GET `/produtos`
- GET `/produtos/disponiveis`
- GET `/produtos/restaurante/{restauranteId}`
- PUT `/produtos/{id}`
- DELETE `/produtos/{id}`

Exemplo de produto:

```json
{
  "nome": "Batata Frita",
  "descricao": "Porção média",
  "preco": 12.90,
  "disponivel": true,
  "restauranteId": 2,
  "categoriasIds": [1]
}
```

### Pedidos
- POST `/pedidos`
- GET `/pedidos`
- GET `/pedidos/{id}`
- GET `/pedidos/cliente/{clienteId}`
- GET `/pedidos/restaurante/{restauranteId}`
- PATCH `/pedidos/{id}/status`
- POST `/pedidos/{id}/repetir`
- PATCH `/pedidos/{id}/cancelar`

Exemplo de pedido:

```json
{
  "clienteId": 3,
  "restauranteId": 2,
  "itens": [
    {
      "produtoId": 1,
      "quantidade": 2
    }
  ]
}
```

Atualizar status:

```json
{
  "status": "EM_PREPARO"
}
```

### Pagamentos
- POST `/pagamentos`
- GET `/pagamentos/{id}`

Exemplo:

```json
{
  "pedidoId": 1,
  "metodo": "PIX"
}
```

### Avaliações
- POST `/avaliacoes`
- GET `/avaliacoes`
- GET `/avaliacoes/restaurante/{restauranteId}`
- GET `/avaliacoes/cliente/{clienteId}`
- DELETE `/avaliacoes/{id}`

Exemplo:

```json
{
  "clienteId": 3,
  "restauranteId": 2,
  "nota": 5,
  "comentario": "Muito bom!"
}
```

### Administração
- GET `/usuarios`
- GET `/usuarios/{id}`
- DELETE `/usuarios/{id}`
- GET `/relatorios/resumo`

### Auditoria
- GET `/auditoria`

A auditoria agora é chamada em cadastros, atualizações, exclusões, pedidos, pagamentos e avaliações.
